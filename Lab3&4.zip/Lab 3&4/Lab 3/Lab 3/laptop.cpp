#include "laptops.h"
#include <fstream>
#include <iostream>
#include <sstream>

// Load laptops from CSV file
void Laptops::loadFromFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error: Could not open file " << filename << "\n";
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string brand, model;
        double price;
        int ramSize, storageSize;

        std::getline(ss, brand, ',');
        std::getline(ss, model, ',');
        ss >> price >> ramSize >> storageSize;

        Laptop laptop(brand, model, price, ramSize, storageSize);
        laptopList.push_back(laptop);
    }
    file.close();
}

// Save laptops to CSV file
void Laptops::saveToFile(const std::string& filename) const {
    std::ofstream file(filename);
    if (!file) {
        std::cerr << "Error: Could not write to file " << filename << "\n";
        return;
    }

    for (const auto& laptop : laptopList) {
        file << laptop.getBrand() << "," << laptop.getModel() << ","
            << laptop.getPrice() << "," << laptop.getRamSizeGB() << ","
            << laptop.getStorageSizeGB() << "\n";
    }
    file.close();
}

// Display all laptops
void Laptops::displayAll() const {
    for (const auto& laptop : laptopList) {
        laptop.detailLine();
    }
}

// Display laptops filtered by brand or RAM size
void Laptops::displayFiltered(const std::string& brand, int ramSize) const {
    for (const auto& laptop : laptopList) {
        if ((brand.empty() || laptop.getBrand() == brand) &&
            (ramSize == 0 || laptop.getRamSizeGB() == ramSize)) {
            laptop.detailLine();
        }
    }
}

// Add a new laptop
void Laptops::addLaptop(const Laptop& laptop) {
    laptopList.push_back(laptop);
}

// Remove a laptop by barcode
void Laptops::removeLaptop(int barcode) {
    laptopList.remove_if([barcode](const Laptop& laptop) {
        return laptop.getBarcode() == barcode;
        });
}

// Modify a laptop by barcode
void Laptops::modifyLaptop(int barcode) {
    for (auto& laptop : laptopList) {
        if (laptop.getBarcode() == barcode) {
            laptop.getValues();
            return;
        }
    }
    std::cout << "Laptop with barcode " << barcode << " not found.\n";
}
