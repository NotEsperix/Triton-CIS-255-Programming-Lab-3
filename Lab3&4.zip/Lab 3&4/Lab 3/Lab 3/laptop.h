#ifndef LAPTOPS_H
#define LAPTOPS_H

#include "laptop.h"
#include <list>
#include <string>

class Laptops {
private:
    std::list<Laptop> laptopList;

public:
    // Load laptops from a file
    void loadFromFile(const std::string& filename);

    // Save laptops to a file
    void saveToFile(const std::string& filename) const;

    // Display all laptops
    void displayAll() const;

    // Filter laptops by brand or RAM size
    void displayFiltered(const std::string& brand = "", int ramSize = 0) const;

    // Add a new laptop
    void addLaptop(const Laptop& laptop);

    // Remove a laptop by barcode
    void removeLaptop(int barcode);

    // Modify a laptop by barcode
    void modifyLaptop(int barcode);

    // Find laptop by barcode
    Laptop* findLaptopByBarcode(int barcode);
};

#endif
