#include "laptops.h"
#include <iostream>

// Function to display the menu
void showMenu() {
    std::cout << "1. Display All Laptops\n";
    std::cout << "2. Display Filtered Laptops\n";
    std::cout << "3. Add Laptop\n";
    std::cout << "4. Remove Laptop\n";
    std::cout << "5. Modify Laptop\n";
    std::cout << "6. Save to File\n";
    std::cout << "7. Load from File\n";
    std::cout << "8. Exit\n";
}

// Main program
int main() {
    Laptops laptops;
    int choice;

    do {
        showMenu();
        std::cin >> choice;

        switch (choice) {
        case 1:  // Display all laptops
            laptops.displayAll();
            break;

        case 2: {  // Display filtered laptops
            std::string brand;
            int ramSize;
            std::cout << "Enter brand (or leave blank): ";
            std::cin.ignore();
            std::getline(std::cin, brand);
            std::cout << "Enter RAM size (or 0 to ignore): ";
            std::cin >> ramSize;
            laptops.displayFiltered(brand, ramSize);
            break;
        }

        case 3: {  // Add laptop
            Laptop laptop;
            laptop.getValues();
            laptops.addLaptop(laptop);
            break;
        }

        case 4: {  // Remove laptop
            int barcode;
            std::cout << "Enter the barcode to remove: ";
            std::cin >> barcode;
            laptops.removeLaptop(barcode);
            break;
        }

        case 5: {  // Modify laptop
            int barcode;
            std::cout << "Enter the barcode to modify: ";
            std::cin >> barcode;
            laptops.modifyLaptop(barcode);
            break;
        }

        case 6: {  // Save to file
            laptops.saveToFile("laptops.csv");
            std::cout << "Laptops saved to file.\n";
            break;
        }

        case 7: {  // Load from file
            laptops.loadFromFile("laptops.csv");
            std::cout << "Laptops loaded from file.\n";
            break;
        }

        case 8:
            std::cout << "Exiting program.\n";
            break;

        default:
            std::cout << "Invalid option. Try again.\n";
        }
    } while (choice != 8);

    return 0;
}
